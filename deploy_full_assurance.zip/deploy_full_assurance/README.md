# Déploiement assurance

Application Streamlit pour calculer :
- PPNA
- Provision d'égalisation (PE)
- SAP / Ecart règlement
- IBNR (Chain Ladder)
- PB

## Fichiers à mettre sur GitHub
- app.py
- processors.py
- requirements.txt
- README.md

## Lancer en local
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Déployer sur Streamlit Community Cloud
1. Créer un dépôt GitHub.
2. Mettre ces fichiers à la racine.
3. Aller sur Streamlit Community Cloud.
4. Choisir le repo et sélectionner `app.py`.
5. Déployer.
